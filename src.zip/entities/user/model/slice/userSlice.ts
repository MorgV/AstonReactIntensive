// src/entities/user/model/slice/userSlice.ts
import { createSlice, createEntityAdapter } from "@reduxjs/toolkit";
import type { IUser } from "../IUser";
import { usersApi } from "../../api/usersApi";

const usersAdapter = createEntityAdapter<IUser>({
  selectId: (user: IUser) => user.id,
  sortComparer: (a, b) => a.id - b.id,
});

const initialState = usersAdapter.getInitialState({
  isLoading: false,
  error: "",
});

export const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addMatcher(
      usersApi.endpoints.fetchUsers.matchFulfilled,
      (state, action) => {
        usersAdapter.setAll(state, action.payload);
      }
    );
  },
});

export const usersSelectors = usersAdapter.getSelectors(
  (state: any) => state.userReducer
);

export default userSlice.reducer;
