import { PostList } from "../../widgets/PostList/PostList";

export const PostsPage = () => {
  return <PostList />;
};
