// src/pages/UserAlbumsPage/UserAlbumsPage.tsx
import { type FC } from "react";
import { useParams } from "react-router-dom";
import { albumsApi } from "../../entities/albums/api/albumsApi";
import { AlbumList } from "../../widgets/AlbumList/AlbumList";
import { skipToken } from "@reduxjs/toolkit/query";

export const UserAlbumsPage: FC = () => {
  const { id } = useParams<{ id: string }>();
  const userIdNum = id ? Number(id) : undefined;
  const { data: albums = [], isLoading } = albumsApi.useFetchUserAlbumsQuery(
    userIdNum ?? skipToken
  );
  console.log(albums);
  return <AlbumList albums={albums} isLoading={isLoading} />;
};
