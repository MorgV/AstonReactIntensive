// src/pages/UserTodosPage/UserTodosPage.tsx
import { type FC } from "react";
import { useParams } from "react-router-dom";
import { todosApi } from "../../entities/todo/api/todosApi";
import { TodoList } from "../../widgets/TodoList/TodoList";

export const UserTodosPage: FC = () => {
  const { id } = useParams<{ id: string }>();
  const { data: todos = [], isLoading } = todosApi.useFetchUserTodosQuery(
    Number(id)
  );

  return <TodoList todos={todos} isLoading={isLoading} />;
};
