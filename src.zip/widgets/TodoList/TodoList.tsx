// src/widgets/TodoList/TodoList.tsx
import { type FC, memo } from "react";
import type { ITodo } from "../../entities/todo/model/ITodo";

interface TodoListProps {
  todos: ITodo[];
  isLoading: boolean;
}

export const TodoList: FC<TodoListProps> = memo(({ todos, isLoading }) => {
  if (isLoading) return <div>Loading...</div>;

  return (
    <ul>
      {todos.map((todo) => (
        <li key={todo.id}>
          {todo.title} {todo.completed ? "(Done)" : "(Pending)"}
        </li>
      ))}
    </ul>
  );
});
